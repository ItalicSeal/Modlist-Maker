browser.downloads.onCreated.addListener(handleDownload);

function handleDownload(downloadItem) {
    browser.downloads.cancel(downloadItem.id);
}